package DAY10;

public class TestArray1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={33,3,4,5};//declaration, instantiation and initialization  
		//printing array  
		for(int i=0;i<a.length;i++)//length is the property of array  
		System.out.println(a[i]);  
	}

}