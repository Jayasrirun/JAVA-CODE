package DAY11Exception;

public class NestedTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}