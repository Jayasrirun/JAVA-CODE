package DAY5inheritance;

public class Demo {

	public static void main(String[] args) {
		Student stud = new Student("Reventh", "Chennai", 1234567890, 23, "ABC");
		System.out.println(stud);

	}

}		
