package DAY3;

public class encapsdemo {

	public static void main(String[] args) {
		encaps e = new encaps();
		e.setId(5397);
		e.setName("Reventh K");
		System.out.println(e);

	}

}