package DAY8basic;

public interface MyInterface {
	void calulateArea();
	
		interface MyInnerInterface{
			int id = 5;
			void print();
		}

}