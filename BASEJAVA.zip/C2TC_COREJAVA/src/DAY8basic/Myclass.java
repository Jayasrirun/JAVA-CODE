package DAY8basic;

public class Myclass implements MyInterface.MyInnerInterface{

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Print methods of inner interface");
	}

	

}