package DAY8basic;

public class Greetclass implements GreetInterface {

	@Override
	public String greet() {
		return "Welcome to the class C9 Batch";
	}

}