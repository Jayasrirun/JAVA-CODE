package DAY8basic;

public interface GreetInterface {
	//abstract method
	public String greet();

}