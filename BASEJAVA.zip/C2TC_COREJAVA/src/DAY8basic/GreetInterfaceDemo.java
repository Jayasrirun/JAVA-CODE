package DAY8basic;

public class GreetInterfaceDemo {

	public static void main(String[] args) {
		Greetclass g = new Greetclass();
		System.out.println(g.greet());
	}

}
