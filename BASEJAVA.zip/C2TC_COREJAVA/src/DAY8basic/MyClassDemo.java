package DAY8basic;

public class MyClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Myclass m = new Myclass();
		m.print();
		System.out.println(Myclass.id);
	}

}