package DAY5hiarchical;

public class Parent {
	void name() {
		System.out.println("Parent name");
	}
	void address() {
		System.out.println("Address");
	}
	void phno() {
		System.out.println("Phone number");
	}
	public static void main(String[] args) {
		

	}

}